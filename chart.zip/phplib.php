<?php
session_start();
if(!isset($_SESSION['title'])){
    $_SESSION["title"]='My Average Day'; $_SESSION["label"]='Task'; $_SESSION["label_diff"]='Hours per Day'; $_SESSION["task1"]='Work'; $_SESSION["task1_value"]='8'; $_SESSION["task2"]='Eat'; $_SESSION["task2_value"]='2'; $_SESSION["task3"]='TV'; $_SESSION["task3_value"]='2'; $_SESSION["task4"]='Gym'; $_SESSION["task4_value"]='2'; $_SESSION["task5"]='Sleep'; $_SESSION["task5_value"]='8'; $_SESSION["chart_type"]='PieChart';
} 
   $new_id= $_POST['new_id'];
 
    if(isset($_POST['field_data'])){
        //  print_r($_SESSION);
        if($new_id=="chart_title"){
            $_SESSION["title"]=$_POST['field_data']; 
        }else if($new_id=="label"){
            $_SESSION["label"]=$_POST['field_data'];
        }else if($new_id=="label_diff"){
            $_SESSION["label_diff"]=$_POST['field_data'];
        }else if($new_id=="task1"){
            $_SESSION["task1"]=$_POST['field_data'];
        }else if($new_id=="task1_value"){
            $_SESSION["task1_value"]=$_POST['field_data'];
        }else if($new_id=="task2"){
            $_SESSION["task2"]=$_POST['field_data'];
        }else if($new_id=="task2_value"){
            $_SESSION["task2_value"]=$_POST['field_data'];
        }else if($new_id=="task3"){
            $_SESSION["task3"]=$_POST['field_data'];
        }else if($new_id=="task3_value"){
            $_SESSION["task3_value"]=$_POST['field_data'];
        }else if($new_id=="task4"){
            $_SESSION["task4"]=$_POST['field_data'];
        }else if($new_id=="task4_value"){
            $_SESSION["task4_value"]=$_POST['field_data'];
        }else if($new_id=="task5"){
            $_SESSION["task5"]=$_POST['field_data'];
        }else if($new_id=="task5_value"){
            $_SESSION["task5_value"]=$_POST['field_data'];
        }else if($new_id=="chart_type"){
            $_SESSION["chart_type"]=$_POST['field_data'];
        }
        echo drawPiechart('piechart1',$_SESSION["title"],$_SESSION["label"],$_SESSION["label_diff"],$_SESSION["task1"],$_SESSION["task1_value"],$_SESSION["task2"],$_SESSION["task2_value"],$_SESSION["task3"],$_SESSION["task3_value"],$_SESSION["task4"],$_SESSION["task4_value"],$_SESSION["task5"],$_SESSION["task5_value"],$_SESSION["chart_type"]);
    }
?>

<?php
    function drawPiechart($chart_name,$title,$label,$label_diff,$task1,$task1_value,$task2,$task2_value,$task3,$task3_value,$task4,$task4_value,$task5,$task5_value,$chart_type){
?>
    
        <h2><?php echo $title; ?></h2>
        <div id="<?php echo $chart_name;?>" class="chart-draw"></div>
        
    
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    
    <script type="text/javascript">
    // Load google charts
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    
    // Draw the chart and set the chart values
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
      ['<?php echo $label;?>', '<?php echo $label_diff;?>'],
      ['<?php echo $task1;?>', <?php echo $task1_value;?>],
      ['<?php echo $task2;?>', <?php echo $task2_value;?>],
      ['<?php echo $task3;?>', <?php echo $task3_value;?>],
      ['<?php echo $task4;?>', <?php echo $task4_value;?>],
      ['<?php echo $task5;?>', <?php echo $task5_value;?>],
    ]);
    
      // Optional; add a title and set the width and height of the chart
      var options = {'title':'<?php echo $title;?>'};
    
      // Display the chart inside the <div> element with id="piechart"
      var chart = new google.visualization.<?php echo $chart_type;?>(document.getElementById('<?php echo $chart_name;?>'));
      chart.draw(data, options);
    }
    </script>
<?php
    }
?>

<?php
    if(isset($_POST['sgraph'])){
        showPiechartcode('piechart1',$_SESSION["title"],$_SESSION["label"],$_SESSION["label_diff"],$_SESSION["task1"],$_SESSION["task1_value"],$_SESSION["task2"],$_SESSION["task2_value"],$_SESSION["task3"],$_SESSION["task3_value"],$_SESSION["task4"],$_SESSION["task4_value"],$_SESSION["task5"],$_SESSION["task5_value"],$_SESSION["chart_type"]);
    } 
    function showPiechartcode($chart_name,$title,$label,$label_diff,$task1,$task1_value,$task2,$task2_value,$task3,$task3_value,$task4,$task4_value,$task5,$task5_value,$chart_type){
?>
    <xmp style="white-space: pre-wrap; word-break: break-all; padding: 10px;">
        <h2><?php echo $title; ?></h2>
        <div id="<?php echo $chart_name;?>"></div>
        
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    
    <script type="text/javascript">
    // Load google charts
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    
    // Draw the chart and set the chart values
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
      ['<?php echo $label;?>', '<?php echo $label_diff;?>'],
      ['<?php echo $task1;?>', <?php echo $task1_value;?>],
      ['<?php echo $task2;?>', <?php echo $task2_value;?>],
      ['<?php echo $task3;?>', <?php echo $task3_value;?>],
      ['<?php echo $task4;?>', <?php echo $task4_value;?>],
      ['<?php echo $task5;?>', <?php echo $task5_value;?>],
    ]);
    
      // Optional; add a title and set the width and height of the chart
      var options = {'title':'<?php echo $title;?>'};
    
      // Display the chart inside the <div> element with id="piechart"
      var chart = new google.visualization.<?php echo $chart_type;?>(document.getElementById('<?php echo $chart_name;?>'));
      chart.draw(data, options);
    }
    </script>
    </xmp>
<?php
    }
?>