<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Draw Graph/Charts</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css">
<body>
    
    <br><br>
    <section class="show-chart">
        <div class="container">
            <center><h1>Create Graph/Chart</h1></center><br><br>
            <div class="row">
                <div class="col-md-6 col-sm-6 col-12">
                    <section class="spin-loders" id="spin-loder">
                       <div class="spinner-grow spin-color"></div>
                    </section>
                    <div id="show_new_graph">
                         <?php include_once 'phplib.php'; drawPiechart('piechart1','My Average Day','Task','Hours per Day','Work','8','Eat','2','TV','2','Gym','2','Sleep','8','PieChart'); ?>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6">
                    <section class="show-form" id="show-form">
                        <h2>Create Pie Chart</h2>
                          <form id="myForm" method="post">
                            <div class="row">
                              <div class="col-md-6">
                                <input type="text" class="form-control" id="chart_title" placeholder="Enter Chart Title" name="chart-title" oninput=getFieldvalue(this.id)>
                              </div>
                              <div class="col-md-6">
                                <input type="text" class="form-control" id="label" placeholder="Enter Label" name="label" oninput=getFieldvalue(this.id)>
                              </div>
                              <div class="col-md-6">
                                <input type="text" class="form-control" id="label_diff" placeholder="Enter Label Distinguish" name="label_diff" oninput=getFieldvalue(this.id)>
                              </div>
                              <div class="col-md-6">
                                <input type="text" class="form-control" id="task1" placeholder="Enter Task1" name="task1" oninput=getFieldvalue(this.id)>
                              </div>
                              <div class="col-md-6">
                                <input type="text" class="form-control" id="task1_value" placeholder="Enter Task1 Value" name="task1_value" oninput=getFieldvalue(this.id)>
                              </div>
                              <div class="col-md-6">
                                <input type="text" class="form-control" id="task2" placeholder="Enter Task2" name="task2" oninput=getFieldvalue(this.id)>
                              </div>
                              <div class="col-md-6">
                                <input type="text" class="form-control" id="task2_value" placeholder="Enter Task2 Value" name="task2_value" oninput=getFieldvalue(this.id)>
                              </div>
                              <div class="col-md-6">
                                <input type="text" class="form-control" id="task3" placeholder="Enter Task3" name="task3" oninput=getFieldvalue(this.id)>
                              </div>
                              <div class="col-md-6">
                                <input type="text" class="form-control" id="task3_value" placeholder="Enter Task3 Value" name="task3_value" oninput=getFieldvalue(this.id)>
                              </div>
                              <div class="col-md-6">
                                <input type="text" class="form-control" id="task4" placeholder="Enter Task4" name="task4" oninput=getFieldvalue(this.id)>
                              </div>
                              <div class="col-md-6">
                                <input type="text" class="form-control" id="task4_value" placeholder="Enter Task4 Value" name="task4_value" oninput=getFieldvalue(this.id)>
                              </div>
                              <div class="col-md-6">
                                <input type="text" class="form-control" id="task5" placeholder="Enter Task5" name="task5" oninput=getFieldvalue(this.id)>
                              </div>
                              <div class="col-md-6">
                                <input type="text" class="form-control" id="task5_value" placeholder="Enter Task Value" name="task5_value" oninput=getFieldvalue(this.id)>
                              </div>
                              <div class="col-md-6">
                                <select name="chart_type" class="form-control" id="chart_type" oninput=getFieldvalue(this.id)>
                                    <option value="" disabled selected>Select Chart Type</option>
                                    <option value="PieChart">Pie Chart</option>
                                    <option value="BarChart">Bar Chart</option>
                                    <option value="ColumnChart">ColumnChart</option>
                                </select>
                              </div>
                              <div class="col-md-12">
                                  <div id="all-reset"></div>
                                <center><button  class="btn btn-primary mt-3" onclick="resetInpufield();">Reset</button></center>
                              </div>
                            </div>
                            
                          </form>
                    </section>
                </div>
            </div>
        </div>
    </section>
    
    <section class="show-code mb2">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <h2>Pie Chart Code</h2>
                    <p>Copy and Paste this code into your website.</p>
                    <div id="code-display" style="border: 5px ridge #b8b8b8;background-color: #f0f0f0;"></div>
                </div>
            </div>
        </div>
        <a class="bottomright">Get Source Code</a>
    </section>

    <script>
        function getFieldvalue(id){
             var data_value= document.getElementById(id).value;
             console.log(data_value);
        
            $.ajax({  
                url:"phplib.php",  
                method:"POST",  
                data:{field_data:data_value,new_id:id},
                beforeSend: function() {
                    $('#spin-loder').show();
                    $('#show_new_graph').hide();
                },
                success:function(data){ 
                    $('#spin-loder').hide();
                    $('#show_new_graph').show();
                $('#show_new_graph').html(data); 
                showGraphcode();
                }  
            }); 
        }
        
        function resetInpufield(){
            var session='unset all varibles';
            document.getElementById("myForm").reset();
            $.ajax({  
                url:"session-distroy.php",  
                method:"POST",  
                data:{new_session:session},
                // beforeSend: function() {
                //     $('#'+ loader).show();
                // },
                success:function(data){ 
                    // $('#'+ loader).hide();
                $('#all-reset').html(data); 
                }  
            }); 
        }
        
        function showGraphcode(){
            var sgraph='show_graph';
            $.ajax({  
                url:"phplib.php",  
                method:"POST",  
                data:{sgraph:sgraph},
                // beforeSend: function() {
                //     $('#'+ loader).show();
                // },
                success:function(data){ 
                    // $('#'+ loader).hide();
                $('#code-display').html(data); 
                }  
            }); 
        }
        
        $( document ).ready(function() {
            $('#spin-loder').hide();
            showGraphcode();
        });
     </script>

</body>
</html>
